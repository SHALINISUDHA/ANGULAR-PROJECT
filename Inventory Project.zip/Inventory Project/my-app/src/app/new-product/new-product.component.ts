import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-new-product',
  templateUrl: './new-product.component.html',
  styleUrls: ['./new-product.component.css']
})
export class NewProductComponent implements OnInit {
  user: FormGroup;
  productList: any = [];
  @Output() productsList: EventEmitter<any> = new EventEmitter();
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.user = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(2)]],
      price: ['', [Validators.required, Validators.minLength(2)]],
      description: ['', Validators.required]
    });
  }

  onSubmit({ value, valid }: { value: any, valid: boolean }) {
    const product = value;
    this.productList.push(product);
    this.productsList.emit(this.productList);
  }
}
