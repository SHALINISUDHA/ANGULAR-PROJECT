import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-products-lists',
  templateUrl: './products-lists.component.html',
  styleUrls: ['./products-lists.component.css']
})
export class ProductsListsComponent implements OnInit {
  @Input() productList: any
  showProductView: boolean = false;
  setSelectedProduct: any;
  @Output() productView = new EventEmitter<boolean>();
  constructor() { }

  ngOnInit() {
    console.log(this.productList);
    this.showProductView = false;
  }

  deleteProduct(item: any) {
    const prodList = this.productList.filter(product => product.name !== item.name);
    this.productList = prodList;
  }

  proceedToProduct(item: any) {
    this.showProductView = true;
    this.setSelectedProduct = item;
    this.productView.emit(true)
  }

  goBackToProducts() {
    this.productView.emit(false);
    this.showProductView = false;
  }

}
