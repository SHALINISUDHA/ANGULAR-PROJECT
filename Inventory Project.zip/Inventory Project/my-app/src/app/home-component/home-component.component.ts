import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-component',
  templateUrl: './home-component.component.html',
  styleUrls: ['./home-component.component.css']
})
export class HomeComponentComponent implements OnInit {
  title = "Add New product";
  productList: any;
  showProductView: boolean;
  constructor() { }

  ngOnInit() {
  }

  setProductList(products: any) {
    this.productList = products;
  }

  setProductView(item: boolean) {
    this.showProductView = item;
  }

}
